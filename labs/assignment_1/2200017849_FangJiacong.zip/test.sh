#!/bin/bash
PYTHONPATH=. python -m unittest discover -s test -p "test_*.py"